﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphReportAutomation
{
    class MSGraphRequests
    {

        public static async Task WriteReports (string tenantId, string aadToken)
        {
            await GetOffice365ActiveUserDetail(tenantId, aadToken, "D30");
        }
        // gets the report https://developer.microsoft.com/en-us/graph/docs/api-reference/beta/api/reportroot_getoffice365activeuserdetail
        // parameter period is string describing time period
       public static async Task GetOffice365ActiveUserDetail(string tenantId, string aadToken, string period="D30")
        {

            string requestUrl = string.Format("{0}/beta/reports/getOffice365ActiveUserDetail(period='{1}')?$format=text/csv", SettingsHelper.AzureMsGraphApiEndpoint, period);

            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Authorization", string.Format("{0}{1}", "Bearer ", aadToken));
            //headers.Add("Accept", "text/csv ");

            DataTable data = RestHelper.DoGetDataTable(tenantId, requestUrl, headers);
            
            await AzureStorageService.AppendToBlob("getOffice365ActiveUserDetail.csv", data);
            return;
        }
    }
}
