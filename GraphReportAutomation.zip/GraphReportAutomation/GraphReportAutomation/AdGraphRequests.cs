﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.ActiveDirectory.GraphClient;
using Microsoft.Azure.ActiveDirectory.GraphClient.Extensions;

namespace GraphReportAutomation
{
    class AdGraphRequests
    {
        public static async Task <string>  RegisterAppForReporting(string tenantId, string domain)
        {

            ActiveDirectoryClient client;

            //*********************************************************************
            // create Microsoft Graph client for user...
            //*********************************************************************
            try
            {
               client = AuthenticationHelper.GetActiveDirectoryClientAsUser(tenantId);
               
            }
            catch (Exception e)
            {
                Program.WriteError("Acquiring a token failed with the following error: {0}",
                    Program.ExtractErrorMessage(e));
                //TODO: Implement retry and back-off logic per the guidance given here:http://msdn.microsoft.com/en-us/library/dn168916.aspx
                Console.ReadKey();
                return (string)null;
            }
          
            // show tenant information to confirm tenant we operate on
            ITenantDetail tenantDetail = await GetTenantDetails(client, tenantId);
            //get admin user  - assume it always exist in customer tenant. We will set him as owner of the reporting application
            var reportUser = client.Users.Where(u => u.UserPrincipalName.Equals(SettingsHelper.ReportUserId+"@" + domain)).ExecuteAsync().Result.CurrentPage.FirstOrDefault();
            if (reportUser != null)
            {
                await ResetUserPassword(reportUser);
            }
            else
            {
                reportUser = await CreateNewUser(client,  tenantDetail.VerifiedDomains.First(x => x.@default.HasValue && x.@default.Value));
            }
            /*
            newUser = await CreateNewUser(client,
                    tenantDetail.VerifiedDomains.First(x => x.@default.HasValue && x.@default.Value));

            await UpdateNewUser(newUser);
            await ResetUserPassword(newUser);
            */




            ServicePrincipal newServicePrincipal = null;
            OAuth2PermissionGrant newPermissionGrant = null;

            //List the aplications registered on the tenant
            await PrintApplications(client);

            //get admin user  - assume it always exist in customer tenant. We will set him as owner of the reporting application
            var ownerUser = client.Users.Where(u => u.UserPrincipalName.Equals("admin@" + domain)).ExecuteAsync().Result.CurrentPage.FirstOrDefault();

            Application application = null;
            //check if there is already a reporting application created in customer directory with display name
            application =  client.Applications.Where(a => a.DisplayName.Equals("MS Graph Reports App")).ExecuteAsync().Result.CurrentPage.FirstOrDefault() as Application;
            if (application == null) // create application if does not exist
            {
                application = await CreateNewApplication(client, ownerUser);                
                newServicePrincipal = await CreateServicePrincipal(client, application);
                //assign delegated permission for App+User authentication
                newPermissionGrant = await CreateOAuth2Permission(client, newServicePrincipal);
            }
            return application.AppId;
        }
        private static async Task PrintApplications(IActiveDirectoryClient client)
        {

            //*********************************************************************
            // get the Application objects
            //*********************************************************************
            IPagedCollection<IApplication> applications = null;
            try
            {
                applications = await client.Applications.Take(50).ExecuteAsync();
            }
            catch (Exception e)
            {
                Program.WriteError("\nError getting Applications {0}", Program.ExtractErrorMessage(e));
            }
            if (applications != null)
            {
                do
                {
                    List<IApplication> appsList = applications.CurrentPage.ToList();
                    foreach (IApplication app in appsList)
                    {
                        Console.WriteLine("Application AppId: {0}  Name: {1}", app.AppId, app.DisplayName);
                    }
                    applications = await applications.GetNextPageAsync();
                } while (applications != null);
            }

        }
        private static async Task<ITenantDetail> GetTenantDetails(IActiveDirectoryClient client, string tenantId)
        {
            //*********************************************************************
            // The following section may be run by any user, as long as the app
            // has been granted the minimum of User.Read (and User.ReadWrite to update photo)
            // and User.ReadBasic.All scope permissions. Directory.ReadWrite.All
            // or Directory.AccessAsUser.All will also work, but are much more privileged.
            //*********************************************************************


            //*********************************************************************
            // Get Tenant Details
            // Note: update the string TenantId with your TenantId.
            // This can be retrieved from the login Federation Metadata end point:             
            // https://login.windows.net/GraphDir1.onmicrosoft.com/FederationMetadata/2007-06/FederationMetadata.xml
            //  Replace "GraphDir1.onMicrosoft.com" with any domain owned by your organization
            // The returned value from the first xml node "EntityDescriptor", will have a STS URL
            // containing your TenantId e.g. "https://sts.windows.net/4fd2b2f2-ea27-4fe5-a8f3-7b1a7c975f34/" is returned for GraphDir1.onMicrosoft.com
            //*********************************************************************

            ITenantDetail tenant = null;
            Console.WriteLine("\n Retrieving Tenant Details");

            try
            {
                IPagedCollection<ITenantDetail> tenantsCollection = await client.TenantDetails
                    .Where(tenantDetail => tenantDetail.ObjectId.Equals(tenantId))
                    .ExecuteAsync();
                List<ITenantDetail> tenantsList = tenantsCollection.CurrentPage.ToList();

                if (tenantsList.Count > 0)
                {
                    tenant = tenantsList.First();
                }
            }
            catch (Exception e)
            {
                Program.WriteError("\nError getting TenantDetails {0}", Program.ExtractErrorMessage(e));
            }

            if (tenant == null)
            {
                Console.WriteLine("Tenant not found");
                return null;
            }
            else
            {
                TenantDetail tenantDetail = (TenantDetail)tenant;
                Console.WriteLine("Tenant Display Name: " + tenantDetail.DisplayName);

                // Get the Tenant's Verified Domains 
                var initialDomain = tenantDetail.VerifiedDomains.First(x => x.Initial.HasValue && x.Initial.Value);
                Console.WriteLine("Initial Domain Name: " + initialDomain.Name);
                var defaultDomain = tenantDetail.VerifiedDomains.First(x => x.@default.HasValue && x.@default.Value);
                Console.WriteLine("Default Domain Name: " + defaultDomain.Name);

                // Get Tenant's Tech Contacts
                foreach (string techContact in tenantDetail.TechnicalNotificationMails)
                {
                    Console.WriteLine("Tenant Tech Contact: " + techContact);
                }
                return tenantDetail;
            }

        }
        private static async Task<string> GetServicePrincipalObjectId(IActiveDirectoryClient client, string applicationId)
        {
            IPagedCollection<IServicePrincipal> servicePrincipals = null;
            try
            {
                servicePrincipals = await client.ServicePrincipals.ExecuteAsync();
            }
            catch (Exception e)
            {
                Program.WriteError("\nError getting Service Principal {0}", e.Message, Program.ExtractErrorMessage(e));
            }

            while (servicePrincipals != null)
            {
                List<IServicePrincipal> servicePrincipalsList = servicePrincipals.CurrentPage.ToList();
                IServicePrincipal servicePrincipal =
                    servicePrincipalsList.FirstOrDefault(x => x.AppId.Equals(applicationId));

                if (servicePrincipal != null)
                {
                    return servicePrincipal.ObjectId;
                }

                servicePrincipals = await servicePrincipals.GetNextPageAsync();
            }
            return string.Empty;
        }
        private static async Task<ServicePrincipal> CreateServicePrincipal(IActiveDirectoryClient client, IApplication application)
        {

            //*********************************************************************************************
            // create a new Service principal, from the application object that was just created
            //*********************************************************************************************
            ServicePrincipal newServicePrincipal = new ServicePrincipal();
            if (application.AppId != null)
            {
                newServicePrincipal.DisplayName = application.DisplayName;
                newServicePrincipal.AccountEnabled = true;
                newServicePrincipal.AppId = application.AppId;

                try
                {
                    await client.ServicePrincipals.AddServicePrincipalAsync(newServicePrincipal);
                    Console.WriteLine("New Service Principal created: " + newServicePrincipal.DisplayName);
                    Console.WriteLine("New Service Principal ObjectId: " + newServicePrincipal.ObjectId);
                }
                catch (Exception e)
                {
                    Program.WriteError("\nError Creating Service Principal: {0}", Program.ExtractErrorMessage(e));
                }
            }
            return newServicePrincipal;
        }
        private static async Task<Application> CreateNewApplication(IActiveDirectoryClient client, IUser user)
        {

            //*********************************************************************************************
            // Create a new Application object, with an App Role definition
            //*********************************************************************************************
            Application newApp = new Application
            {
                DisplayName = "MS Graph Reports App" // Used in testing+ Helper.GetRandomString(4),
            };
            //newApp.IdentifierUris.Add("https://localhost/demo/" + Guid.NewGuid());
            newApp.ReplyUrls.Add("http://localhost");
            // change to true if Native client, false for Web
            newApp.PublicClient = true;
           
            
            // Add permission to Graph API
            var AADAccess = new RequiredResourceAccess();
            AADAccess.ResourceAppId = "00000002-0000-0000-c000-000000000000";
            
            AADAccess.ResourceAccess.Add(new ResourceAccess()
            {
                //"Access the directory as the signed-in user del. permission"
                Id = Guid.Parse("a42657d6-7f20-40e3-b6f0-cee03008a62a"),
                Type = "Scope",
            });
                        
            // Add permission to Microsoft Graph API
            var MGAccess = new RequiredResourceAccess();
            // Microsoft Graph API
            MGAccess.ResourceAppId = "00000003-0000-0000-c000-000000000000";
            
            MGAccess.ResourceAccess.Add(new ResourceAccess()
            {
                //"Read all reports delegated permission"
                Id = Guid.Parse("02e97553-ed7b-43d0-ab3c-f8bace0d040c"),
                Type = "Scope",
            });
           
            newApp.RequiredResourceAccess.Add(AADAccess);
            //newApp.RequiredResourceAccess.Add(RMAccess);
            newApp.RequiredResourceAccess.Add(MGAccess);


            try
            {
                await client.Applications.AddApplicationAsync(newApp);
                Console.WriteLine("New Application created: " + newApp.DisplayName + " AppId=" + newApp.AppId + " ObjectId=" + newApp.ObjectId);
            }
            catch (Exception e)
            {
                Program.WriteError("\nError ceating Application: {0}", Program.ExtractErrorMessage(e));
            }

            // add an owner for the newly created application

            newApp.Owners.Add(user as DirectoryObject);
            try
            {
                await newApp.UpdateAsync();
                Console.WriteLine("Added owner: " + newApp.DisplayName, user.DisplayName);
            }
            catch (Exception e)
            {
                Program.WriteError("\nError adding Application owner: {0}", Program.ExtractErrorMessage(e));
            }

            // check the ownership for the newly created application
            try
            {
                IApplication appCheck = await client.Applications.GetByObjectId(newApp.ObjectId).ExecuteAsync();
                IApplicationFetcher appCheckFetcher = appCheck as IApplicationFetcher;

                IPagedCollection<IDirectoryObject> appOwners = await appCheckFetcher.Owners.ExecuteAsync();

                do
                {
                    List<IDirectoryObject> directoryObjects = appOwners.CurrentPage.ToList();
                    foreach (IDirectoryObject directoryObject in directoryObjects)
                    {
                        if (directoryObject is User)
                        {
                            User appOwner = directoryObject as User;
                            Console.WriteLine("Application {0} has {1} as owner", appCheck.DisplayName,
                                appOwner.DisplayName);
                        }
                    }
                    appOwners = await appOwners.GetNextPageAsync();
                } while (appOwners != null);
            }
            catch (Exception e)
            {
                Program.WriteError("\nError checking Application owner: {0}", Program.ExtractErrorMessage(e));
            }

            return newApp;

        }
        private static async Task<OAuth2PermissionGrant> CreateOAuth2Permission(IActiveDirectoryClient client, ServicePrincipal servicePrincipal)
        {

            //*********************************************************************************************
            // Create new  oauth2 permission object
            //********************************************************************************************
            if (servicePrincipal.ObjectId != null)
            {
                OAuth2PermissionGrant permissionObject1 = new OAuth2PermissionGrant
                {
                    ConsentType = "AllPrincipals",
                    Scope = "Reports.Read.All",
                    StartTime = DateTime.Now,
                    ExpiryTime = (DateTime.Now).AddYears(10),
                    ResourceId = await GetServicePrincipalObjectId(client, GlobalConstants.MsGraphServiceObjectId),
                    ClientId = servicePrincipal.ObjectId
                };
                OAuth2PermissionGrant permissionObject2 = new OAuth2PermissionGrant
                {
                    ConsentType = "AllPrincipals",
                    Scope = "user_impersonation",
                    StartTime = DateTime.Now,
                    ExpiryTime = (DateTime.Now).AddYears(10),
                    ResourceId = await GetServicePrincipalObjectId(client, GlobalConstants.GraphServiceObjectId),
                    ClientId = servicePrincipal.ObjectId
                };
                try
                {
                    await client.Oauth2PermissionGrants.AddOAuth2PermissionGrantAsync(permissionObject1);
                    await client.Oauth2PermissionGrants.AddOAuth2PermissionGrantAsync(permissionObject2);
                    Console.WriteLine("New Permission object created: " + permissionObject1.ObjectId);
                    Console.WriteLine("New Permission object created: " + permissionObject2.ObjectId);
                }
                catch (Exception e)
                {
                    Program.WriteError("\nError with Permission Creation: {0}", Program.ExtractErrorMessage(e));
                }

                return permissionObject1;
            }


            return null;
        }
        private static async Task ResetUserPassword(IUser user)
        {

            //*******************************************************************************************
            // update the newly created user's Password and PasswordPolicies
            // requires Directory.AccessAsUser.All and that the current user is a user, helpdesk or company admin
            //*********************************************************************************************
            if (user.ObjectId != null)
            {
                // update User's password policy and reset password - forcing change password at next logon
                PasswordProfile PasswordProfile = new PasswordProfile
                {
                    Password = SettingsHelper.ReportUserPassword,
                    ForceChangePasswordNextLogin = false
                };
                user.PasswordProfile = PasswordProfile;
                user.PasswordPolicies = "DisablePasswordExpiration, DisableStrongPassword";
                try
                {
                    await user.UpdateAsync();
                    Console.WriteLine("\nUser {0} password and policy was reset", user.DisplayName);
                }
                catch (Exception e)
                {
                    Program.WriteError("\nError Updating the user {0}", Program.ExtractErrorMessage(e));
                }
            }

        }
        private static async Task<User> CreateNewUser(IActiveDirectoryClient client, VerifiedDomain defaultDomain)
        {

            // **********************************************************
            // Requires Directory.ReadWrite.All or Directory.AccessAsUser.All, and the signed in user
            // must be a privileged user (like a company or user admin)
            // **********************************************************

            User newUser = new User();
            if (defaultDomain.Name != null)
            {
                Console.WriteLine("\nCreating a new user...");
                
                String firstName = "Report";                
                String lastName = "User";
                newUser.DisplayName = firstName + " " + lastName;
                newUser.UserPrincipalName = SettingsHelper.ReportUserId + "@" + defaultDomain.Name;
                newUser.AccountEnabled = true;
                newUser.MailNickname = firstName + lastName;
                newUser.PasswordProfile = new PasswordProfile
                {
                    Password = SettingsHelper.ReportUserPassword,
                    ForceChangePasswordNextLogin = false
                };
                //newUser.UsageLocation = "US";
                try
                {
                    await client.Users.AddUserAsync(newUser);
                    Console.WriteLine("\nNew User {0} was created", newUser.DisplayName);
                }
                catch (Exception e)
                {
                    Program.WriteError("\nError creating new user {0}", Program.ExtractErrorMessage(e));
                }
            }
            return newUser;

        }
    }
}
