﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System.IO;
using System.Data;

namespace GraphReportAutomation
{
    class AzureStorageService
    {
        static CloudStorageAccount storageAccount = null;
        static CloudBlobContainer cloudBlobContainer = null;

        public static async Task CheckContainer()
        {
            // Check whether the connection string can be parsed.
            if (CloudStorageAccount.TryParse(SettingsHelper.AzureStorgeConnection, out storageAccount))
            {
                try
                {
                    // Create the CloudBlobClient that represents the Blob storage endpoint for the storage account.
                    CloudBlobClient cloudBlobClient = storageAccount.CreateCloudBlobClient();

                    // Create a container called 'quickstartblobs' and append a GUID value to it to make the name unique. 
                    cloudBlobContainer = cloudBlobClient.GetContainerReference("reports");
                    await cloudBlobContainer.CreateIfNotExistsAsync();
                    Console.WriteLine("Created container '{0}'", cloudBlobContainer.Name);
                    Console.WriteLine();

                    // Set the permissions so the blobs are public. 
                    BlobContainerPermissions permissions = new BlobContainerPermissions
                    {
                        PublicAccess = BlobContainerPublicAccessType.Off
                    };
                    await cloudBlobContainer.SetPermissionsAsync(permissions);

                }
                catch (StorageException ex)
                {
                    Console.WriteLine("Error returned from the service: {0}", ex.Message);
                }
            }
        }
        public static async Task AppendToBlob(string reportName, DataTable table)
        {
            await CheckContainer();
            // Get a reference to the blob address, then upload the stream.
            // Append blo is used 
            CloudAppendBlob cloudBlockBlob = cloudBlobContainer.GetAppendBlobReference(reportName);
            bool writeHeader = !cloudBlockBlob.Exists();
            if (!writeHeader && table.Rows.Count == 0)
                return;
            using (MemoryStream ms = new MemoryStream())
            {
                StreamWriter csvWriter = new StreamWriter(ms, Encoding.UTF8);
                WriteDataTable(table, csvWriter, writeHeader);
                ms.Seek(0,SeekOrigin.Begin);
                if (cloudBlockBlob.Exists())
                {
                    await cloudBlockBlob.AppendFromStreamAsync(ms);
                }
                else
                {
                    await cloudBlockBlob.UploadFromStreamAsync(ms);
                }
            }

        }
        private static string QuoteValue(string value)
        {
            return String.Concat("\"",
            value.Replace("\"", "\"\""), "\"");
        }

        public static void WriteDataTable(DataTable table, TextWriter writer, bool writeHeader)
        {
            if (writeHeader)
            {
                IEnumerable<String> headerValues = table.Columns
                    .OfType<DataColumn>()
                    .Select(column => QuoteValue(column.ColumnName));

                writer.WriteLine(String.Join(",", headerValues));
            }

            IEnumerable<String> items = null;

            foreach (DataRow row in table.Rows)
            {
                items = row.ItemArray.Select(o => QuoteValue(o?.ToString() ?? String.Empty));
                writer.WriteLine(String.Join(",", items));
            }
            writer.Flush();
        }

    }
}
