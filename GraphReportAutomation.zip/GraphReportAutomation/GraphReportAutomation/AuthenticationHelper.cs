﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.ActiveDirectory.GraphClient;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Web;

namespace GraphReportAutomation
{
    internal class AuthenticationHelper
    {
        public static string TokenForUser;

        public static async Task<string> GetGraphToken(string tenantId)
        {
            if (TokenForUser != null)
                return TokenForUser;

            var request = WebRequest.Create(SettingsHelper.AadAuthority+ tenantId + @"/oauth2/token");

            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            //string content = string.Format(
            //    "resource={0}&grant_type=password&username={1}&password={2}&client_id={3}&client_secret={4}&scope=openid",
            //    HttpUtility.UrlEncode(GlobalConstants.ResourceUrl),
            //    HttpUtility.UrlEncode(CspConstants.UserName),
            //    HttpUtility.UrlEncode(CspConstants.UserPwd),
            //    HttpUtility.UrlEncode(CspConstants.ClientId),
            //    HttpUtility.UrlEncode(CspConstants.ClientSecret)
            //    );
            string content = string.Format(
                "resource={0}&grant_type=password&username={1}&password={2}&client_id={3}&scope=openid",
                HttpUtility.UrlEncode(SettingsHelper.AzureADGraphApiEndpoint),
                HttpUtility.UrlEncode(SettingsHelper.UserId),
                HttpUtility.UrlEncode(SettingsHelper.UserPassword),
                HttpUtility.UrlEncode(SettingsHelper.ClientId)
                );

            using (var writer = new StreamWriter(request.GetRequestStream()))
            {
                writer.Write(content);
            }

            try
            {
                var response = await request.GetResponseAsync();
                using (var reader = new StreamReader(response.GetResponseStream()))
                {
                    var responseContent = reader.ReadToEnd();
                    var adResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<JObject>(responseContent);
                    TokenForUser = adResponse["access_token"].ToString();
                    return TokenForUser;
                }

            }
            catch (WebException webException)
            {
                if (webException.Response != null)
                {
                    using (var reader = new StreamReader(webException.Response.GetResponseStream()))
                    {
                        var responseContent = reader.ReadToEnd();
                    }
                }
            }

            return null;
        }

        public static ActiveDirectoryClient GetActiveDirectoryClientAsUser(string tenantId)
        {
       
            Uri servicePointUri = new Uri(SettingsHelper.AzureADGraphApiEndpoint);
            // we will be accessing Customer tenant
            Uri serviceRoot = new Uri(servicePointUri, tenantId);
            // tell graph client how to obtain access token for Graph via GetGraphToken delegate
            ActiveDirectoryClient activeDirectoryClient = new ActiveDirectoryClient(serviceRoot,
                async () => await GetGraphToken(tenantId));
            return activeDirectoryClient;
        }

        /// <summary>
        /// Login in azure ad and get the credential
        /// </summary>
        /// <param name="tenantId">the domain</param>
        /// <param name="resource">the resouce to get access token</param>
        /// <returns></returns>
        public static async Task<AuthenticationResult> LoginToAad(string tenantId, string resource, string clientId, string username, string password )
        {
            // auth from azure ad 
            var addAuthority = new UriBuilder(SettingsHelper.AadAuthority + tenantId);
            UserCredential userCredentials = new UserCredential(username, password);
            AuthenticationContext authContext = new AuthenticationContext(addAuthority.Uri.AbsoluteUri);
            return await authContext.AcquireTokenAsync(resource, clientId, userCredentials);
        }

    }
}
