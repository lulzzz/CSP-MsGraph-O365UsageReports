﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Store.PartnerCenter;
using Microsoft.Store.PartnerCenter.Customers;
using Microsoft.Store.PartnerCenter.Extensions;
using Microsoft.Store.PartnerCenter.Models.Customers;

namespace GraphReportAutomation
{
    class PartnerCenterRequests
    {
        public static IPartner CreatePartnerOperations()
        {
            //login Azure AD, for partner center sdk, you can use the "common" as the tenant id
            var aadAuthenticationResult = AuthenticationHelper.LoginToAad("common", SettingsHelper.PartnerCenterApiResourceId, SettingsHelper.ClientId, SettingsHelper.UserId, SettingsHelper.UserPassword).Result;

            //set to use the public partner center api
            PartnerService.Instance.ApiRootUrl = SettingsHelper.PartnerCenterApiEndpoint;

            //get the credential
            var authToken = new AuthenticationToken(aadAuthenticationResult.AccessToken, aadAuthenticationResult.ExpiresOn);
            IPartnerCredentials credentials = PartnerCredentials.Instance.GenerateByUserCredentials(SettingsHelper.ClientId, authToken);
            IPartner partner = PartnerService.Instance.CreatePartnerOperations(credentials);
            return partner;
        }
        public static Customer GetCustomerById(string tenantId, IPartner partner)
        {
            return partner.Customers.ById(tenantId).Get();
        }
    }
 }
