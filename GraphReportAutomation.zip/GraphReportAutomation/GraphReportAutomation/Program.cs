﻿using Microsoft.Store.PartnerCenter.Models.Customers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphReportAutomation
{
    class Program
    {
        // Single-Threaded Apartment required for OAuth2 Authz Code flow (User Authn) to execute for this demo app
        [STAThread]
        static  void Main(string[] args)
        {
            var partner = PartnerCenterRequests.CreatePartnerOperations();
            foreach (string tenantId in SettingsHelper.Customers)
            {
                Customer customer = PartnerCenterRequests.GetCustomerById(tenantId, partner);
                var clientId = Task.Run<string> (async() => await AdGraphRequests.RegisterAppForReporting(tenantId, customer.CompanyProfile.Domain)).GetAwaiter().GetResult();
                //obtain token to MS Graph
                var aadAuthenticationResult = AuthenticationHelper.LoginToAad(tenantId, SettingsHelper.AzureMsGraphApiResourceId, clientId, SettingsHelper.ReportUserId+"@" + customer.CompanyProfile.Domain, SettingsHelper.ReportUserPassword).Result;
                // write downloaded reports to Blob
                MSGraphRequests.WriteReports(tenantId, aadAuthenticationResult.AccessToken).Wait();
            }
            Console.WriteLine("Program completed. Press key to exit.");
            Console.ReadLine();
        }
        public static string ExtractErrorMessage(Exception exception)
        {
            List<string> errorMessages = new List<string>();
            string tabs = "\n";
            while (exception != null)
            {
                tabs += "    ";
                errorMessages.Add(tabs + exception.Message);
                exception = exception.InnerException;
            }
            return string.Join("-\n", errorMessages);
        }

        public static void WriteError(string output, params object[] args)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Error.WriteLine(output, args);
            Console.ResetColor();
        }
    }
}
