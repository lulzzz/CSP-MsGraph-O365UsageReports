﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace GraphReportAutomation
{
    class RestHelper
    {
        


        /// <summary>
        /// Http Get
        /// </summary>
        /// <param name="url"></param>
        /// <param name="headers">headers</param>
        /// <returns>Response stream</returns>
        public static DataTable DoGetDataTable(string tenantId, string url, Dictionary<string, string> headers)
        {
            //Console.WriteLine("url:" + url);
            WebRequest request = WebRequest.Create(url);

            
            if (null != headers)
            {
                //Console.WriteLine("headers start");
                foreach (string key in headers.Keys)
                {
                    //Console.WriteLine(key+":"+ headers[key]);
                    request.Headers.Add(key, headers[key]);
                }
                //Console.WriteLine("headers end");
            }
            request.Method = "GET";
            try
            {

                var response = request.GetResponse();


                using (var reader = new StreamReader(response.GetResponseStream()))
                {
                    var table = new DataTable();
                    table.Columns.Add("tenantId");
                    string[] head = reader.ReadLine().Split(',');
                    foreach (string h in head)
                    {
                        table.Columns.Add(h);
                    }
                    while (!reader.EndOfStream)
                    {
                        string[] cols = reader.ReadLine().Split(',');
                        DataRow dr = table.NewRow();
                        dr[0] = tenantId;
                        for (int i = 0; i < head.Length; i++)
                        {
                            dr[i+1] = cols[i];
                        }
                    }
                    return table;
                }
            }
            // for non Office 365 user will throw Exception 
            // https://stackoverflow.com/questions/46467243/office365activeusers-graph-api-call-returning-not-found-we-do-not-recognize-th

            catch (WebException webException)
            {
                if (webException.Response != null)
                {
                    using (var reader = new StreamReader(webException.Response.GetResponseStream()))
                    {
                        var responseContent = reader.ReadToEnd();
                        Console.WriteLine("responseContent:" + responseContent);
                    }
                }
            }
            return null;
        }
        public static JObject DoGet(string url, Dictionary<string, string> headers)
        {
            //Console.WriteLine("url:" + url);
            var request = WebRequest.Create(url);
            if (null != headers)
            {
                //Console.WriteLine("headers start");
                foreach (string key in headers.Keys)
                {
                    //Console.WriteLine(key+":"+ headers[key]);
                    request.Headers.Add(key, headers[key]);
                }
                //Console.WriteLine("headers end");
            }
            request.Method = "GET";
            try
            {
                var response = request.GetResponse();
                using (var reader = new StreamReader(response.GetResponseStream()))
                {
                    var responseContent = reader.ReadToEnd();
                    //Console.WriteLine("responseContent:" + responseContent);
                    var retJson = Newtonsoft.Json.JsonConvert.DeserializeObject<JObject>(responseContent);
                    return retJson;
                }
            }
            catch (WebException webException)
            {
                if (webException.Response != null)
                {
                    using (var reader = new StreamReader(webException.Response.GetResponseStream()))
                    {
                        var responseContent = reader.ReadToEnd();
                        //Console.WriteLine("responseContent:" + responseContent);
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Http Put
        /// </summary>
        /// <param name="url"></param>
        /// <param name="headers">headers</param>
        /// <param name="content">the json content to put</param>
        /// <returns></returns>
        public static JObject DoPut(string url, Dictionary<string, string> headers, string content)
        {
            //Console.WriteLine("url:" + url);
            var request = WebRequest.Create(url);
            request.ContentType = "application/json";
            if (null != headers)
            {
                //Console.WriteLine("headers start");
                foreach (string key in headers.Keys)
                {
                    //Console.WriteLine(key + ":" + headers[key]);
                    request.Headers.Add(key, headers[key]);
                }
                //Console.WriteLine("headers end");
            }
            request.Method = "PUT";
            if (!string.IsNullOrEmpty(content))
            {
                //Console.WriteLine("content:" + content);
                using (var writer = new StreamWriter(request.GetRequestStream()))
                {
                    writer.Write(content);
                }
            }

            try
            {
                var response = request.GetResponse();
                using (var reader = new StreamReader(response.GetResponseStream()))
                {
                    var responseContent = reader.ReadToEnd();
                    //Console.WriteLine("responseContent:" + responseContent);
                    var retJson =
                        Newtonsoft.Json.JsonConvert.DeserializeObject<JObject>(responseContent);
                    return retJson;
                }

            }
            catch (WebException webException)
            {
                if (webException.Response != null)
                {
                    using (var reader = new StreamReader(webException.Response.GetResponseStream()))
                    {
                        var responseContent = reader.ReadToEnd();
                        //Console.WriteLine("responseContent:" + responseContent);
                    }
                }
            }

            return null;
        }
    }
}
